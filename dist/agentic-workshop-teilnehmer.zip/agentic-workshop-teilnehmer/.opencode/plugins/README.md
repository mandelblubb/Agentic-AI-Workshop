# Plugin-Starter (Gruppe B)

Minimales Startgerüst für Teilnehmende, die in der freien Workshop-Gruppe den
Coding Agenten selbst um Verhalten erweitern wollen.

**Was anderswo „Hook" heißt, heißt in OpenCode Plugin.** Es gibt keinen
Konfigurationsschlüssel `hooks` — ein Plugin ist eine JavaScript-Datei, die
sich auf Ereignisse des Agenten hängt. Die Hook-Namen sind dann die
Ereignisse *innerhalb* des Plugins.

Das ist die einzige der fünf Erweiterungen, die **nicht** über den Prompt
läuft: Command, Skill und Subagent beeinflussen, was das Modell denkt. Ein
Plugin läuft als Code, unabhängig davon, was das Modell vorhat.

Zwei **funktionierende Beispiele**, je eins pro Mechanismus (siehe unten):

- **`edit-log.js`** (generisches Event, `file.edited`): schreibt jede
  Dateiänderung mit Zeitstempel nach `.opencode/edit-log.txt`.
- **`tool-log.js`** (benannter Hook, `tool.execute.before`): schreibt jeden
  Werkzeugaufruf mit Zeitstempel nach `.opencode/tool-log.txt`.

Ausprobieren: OpenCode starten, den Agenten irgendeine Datei ändern lassen
und irgendeine Aufgabe erledigen lassen, danach

```bash
cat .opencode/edit-log.txt
cat .opencode/tool-log.txt
```

Erwartete Ausgabe, eine Zeile je Änderung bzw. je Werkzeugaufruf:

```text
2026-09-07T10:01:06.485Z  C:\...\README.md
2026-09-19T19:32:10.112Z  convention-app-tools_list_events
```

**Beim ersten Start mit einem Plugin legt OpenCode `.opencode/node_modules/`
an** und lädt Abhängigkeiten nach. Das ist normal und dauert einen Moment;
`node_modules` ist bereits in `.opencode/.gitignore` eingetragen.

## Aufbau eines Plugins — zwei verschiedene Mechanismen

**Das ist die Stelle, an der man sich leicht vertut** (uns beim Bauen dieses
Repos genauso passiert): OpenCode kennt zwei unterschiedlich angebundene
Arten von Hooks, nicht einen gemeinsamen.

**1. Generische Events** — laufen über einen einzigen `event`-Handler, der
alles bekommt und selbst filtert:

```javascript
export const MeinPlugin = async ({ directory, project, client, $ }) => {
  return {
    event: async ({ event }) => {
      if (event.type !== "file.edited") return
      // hier passiert etwas
    },
  }
}
```
Dazu gehören: `file.edited`, `session.created`, `session.idle`,
`permission.asked`.

**2. Benannte Tool-Hooks** — eigener, direkt benannter Schlüssel im
Rückgabe-Objekt, andere Signatur (`input`/`output` statt `event`):

```javascript
export const MeinPlugin = async ({ directory, project, client, $ }) => {
  return {
    "tool.execute.before": async (input, output) => {
      // input.tool = Name des aufgerufenen Werkzeugs
      // hier passiert etwas
    },
  }
}
```
Dazu gehören: `tool.execute.before`, `tool.execute.after`.

**Die beiden Stile sind nicht austauschbar.** Ein `tool.execute.before` im
`event`-Handler abzufragen (so wie im `file.edited`-Beispiel oben) sieht
plausibel aus, feuert aber nie — genau das ist uns beim Testen dieses Repos
passiert. `tool-log.js` zeigt den korrekten Weg.

**Welche Daten ein Ereignis/Hook mitbringt, müsst ihr nicht raten.** Nach dem
ersten Start steht es typisiert in

```text
.opencode/node_modules/@opencode-ai/sdk/dist/gen/types.gen.d.ts
```

Für `file.edited` ist es `{ file: string }` — deshalb steht im Beispiel
`event.properties.file`. Für `tool.execute.before` ist es `input.tool`.

## Eigene Plugins ergänzen

Ideen zum Weiterbauen (nur Anregungen, keine Vorgabe):

- auf `session.idle` automatisch `pytest` starten und das Ergebnis melden
- auf `permission.asked` protokollieren, wofür der Agent um Erlaubnis
  gefragt hat und was geantwortet wurde

**Praktischer Tipp:** Auch hier gilt wie bei Command und Skill: nicht zwingend
von Hand tippen. `edit-log.js` oder `tool-log.js` als Vorlage geben und dem
Coding Agenten in Prompt-Form beschreiben, auf welches Ereignis das neue
Plugin reagieren und was es dann tun soll — bei einem Plugin sogar noch mehr
als bei den anderen beiden, weil hier echter JS-Code statt Markdown/Prompt-
Text entsteht. Ihr müsst das Ergebnis lesen und beurteilen können, nicht
selbst schreiben.

## Leitplanken

- Ein Plugin läuft bei **jedem** passenden Ereignis. Haltet es klein und
  schnell, sonst bremst es jede Sitzung.
- Nichts Blockierendes und keine Netzwerkaufrufe.
- Fehler im Plugin können die Sitzung stören — im Zweifel `opencode run
  --pure` starten, das lädt keine Plugins.
