/**
 * Nachvollziehbarkeit: schreibt jeden Werkzeugaufruf des Agenten mit
 * Zeitstempel nach .opencode/tool-log.txt.
 *
 * Anders als edit-log.js (generisches Event "file.edited") ist
 * "tool.execute.before" ein benannter Hook mit eigener Signatur
 * (input, output) statt (event) - siehe README.md, "Aufbau eines
 * Plugins - zwei verschiedene Mechanismen".
 */

import { appendFile } from "node:fs/promises"
import { join } from "node:path"

export const ToolLog = async ({ directory }) => {
  const logPath = join(directory, ".opencode", "tool-log.txt")

  return {
    "tool.execute.before": async (input) => {
      const zeile = `${new Date().toISOString()}  ${input.tool}\n`
      await appendFile(logPath, zeile, "utf8")
    },
  }
}
